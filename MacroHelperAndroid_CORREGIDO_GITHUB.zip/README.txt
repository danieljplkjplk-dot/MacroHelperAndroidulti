Macro Helper Android

Proyecto Android nativo sencillo, con interfaz auxiliar y selector visual de simbolos de mira (+, x, punto y circulo). Las preferencias se guardan localmente.

La app no modifica Free Fire, no automatiza acciones dentro de partidas y no proporciona apuntado automatico.

Compilacion: GitHub Actions -> Build Android APK -> Run workflow.
Artefacto: MacroHelper-debug-apk (contiene app-debug.apk).
