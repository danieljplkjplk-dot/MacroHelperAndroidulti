package com.macrohelper.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int BG=0xFF080B16, PURPLE=0xFF9936FF, MUTED=0xFFB9A2D8;
    private LinearLayout root;
    private SharedPreferences prefs;
    private String selectedSight="○";
    private final String[] names={"Semi autoapuntado","No pasar de cabeza","Fluidez","120 FPS","Levantar mira rápida","Combinación de botones","Auto clicker","Mira"};
    private final String[] keys={"semi","head","smooth","fps","lift","combo","clicker","sight"};
    private final String[] details={
        "Ajuste informativo: esta app no puede controlar la mira ni apuntar por Free Fire.",
        "No existe un ajuste externo que garantice impactos a la cabeza. La app no modifica la sensibilidad del juego.",
        "Consejos de estabilidad: cierra apps en segundo plano y usa el modo de rendimiento del teléfono si está disponible.",
        "La tasa de refresco depende del teléfono y de las opciones que Free Fire ofrezca. Esta app no desbloquea FPS.",
        "Puedes ajustar la sensibilidad y el tamaño del botón de disparo dentro de los ajustes oficiales del juego.",
        "Crea y guarda una referencia visual de botones. No envía pulsaciones al juego.",
        "La automatización de toques dentro de partidas no está incluida. Puedes usar las funciones de accesibilidad propias de Android.",
        "Elige un símbolo de mira para mostrarlo como referencia dentro de esta app."
    };
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("macro_helper",MODE_PRIVATE);selectedSight=prefs.getString("sight_symbol","○");showHome();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void init(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(14),dp(14),dp(14),dp(14));root.setBackgroundColor(BG);setContentView(root);TextView h=text(title,22,Color.WHITE,true);h.setPadding(dp(4),dp(8),dp(4),dp(14));root.addView(h);}
    private void button(LinearLayout parent,String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(shape(0xFF211936,PURPLE,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(5),0,dp(5));parent.addView(b,p);b.setOnClickListener(v->action.run());}
    private void showHome(){init("♛  FF PANEL PRO");TextView sub=text("HERRAMIENTAS Y AJUSTES AUXILIARES",10,MUTED,true);sub.setGravity(Gravity.CENTER);root.addView(sub);ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        for(int i=0;i<names.length;i++){final int x=i;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(4),dp(8),dp(4));row.setBackground(shape(0xFF1B1D2F,0xFF574182,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(66));p.setMargins(0,dp(5),0,dp(5));list.addView(row,p);TextView label=text(names[i],14,Color.WHITE,true);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            if(i==7){TextView symbol=text(selectedSight,25,Color.WHITE,true);row.addView(symbol);row.setOnClickListener(v->showSight());}
            else if(i==5||i==6){row.addView(text("›",28,MUTED,true));row.setOnClickListener(v->showDetail(x));}
            else{Switch sw=new Switch(this);sw.setChecked(prefs.getBoolean(keys[i],false));row.addView(sw);sw.setOnCheckedChangeListener((v,c)->prefs.edit().putBoolean(keys[x],c).apply());row.setOnClickListener(v->sw.setChecked(!sw.isChecked()));}}
        TextView foot=text("Las opciones se guardan en este dispositivo. No alteran Free Fire.",11,MUTED,false);foot.setGravity(Gravity.CENTER);root.addView(foot);}
    private void showDetail(int i){init(names[i]);TextView d=text(details[i],15,Color.WHITE,false);d.setPadding(dp(8),dp(12),dp(8),dp(20));root.addView(d);
        if(i==5){button(root,"Guardar combinación: Disparo + salto",()->saveCombo("Disparo + salto"));button(root,"Guardar combinación: Agacharse + disparo",()->saveCombo("Agacharse + disparo"));button(root,"Guardar combinación: Pared + salto",()->saveCombo("Pared + salto"));TextView saved=text("Combinación guardada: "+prefs.getString("combo_name","Ninguna"),13,MUTED,false);root.addView(saved);}
        if(i==6)root.addView(text("El auto clicker para tocar botones de Free Fire no está incluido en esta app.",13,MUTED,false));button(root,"Volver",this::showHome);}
    private void saveCombo(String s){prefs.edit().putString("combo_name",s).apply();new AlertDialog.Builder(this).setMessage("Guardado: "+s).setPositiveButton("OK",null).show();}
    private void showSight(){init("Diseño de mira");root.addView(text("Selecciona un símbolo como referencia visual:",14,MUTED,false));for(String s:new String[]{"+","×","•","○"})button(root,s+(s.equals(selectedSight)?"   ✓":""),()->{selectedSight=s;prefs.edit().putString("sight_symbol",s).apply();showSight();});TextView preview=text(selectedSight,64,Color.WHITE,true);preview.setGravity(Gravity.CENTER);preview.setBackground(shape(0xFF171A2A,PURPLE,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(130));p.setMargins(0,dp(12),0,dp(12));root.addView(preview,p);button(root,"Volver",this::showHome);}
}
